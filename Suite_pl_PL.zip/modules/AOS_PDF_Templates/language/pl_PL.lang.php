<?php
/**
 * Products, Quotations & Invoices modules.
 * Extensions to SugarCRM
 * @package Advanced OpenSales for SugarCRM
 * @subpackage Products
 * @copyright SalesAgility Ltd http://www.salesagility.com
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Salesagility Ltd <support@salesagility.com>
 */

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'ID Przydzielonego Użytkownika',
  'LBL_ASSIGNED_TO_NAME' => 'Przypisany do',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Wprowadzona Data',
  'LBL_DATE_MODIFIED' => 'Data Modyfikacji:',
  'LBL_MODIFIED' => 'Zmodyfikowane Przez',
  'LBL_MODIFIED_ID' => 'ID Modyfikującego',
  'LBL_MODIFIED_NAME' => 'Imię Modyfikującego',
  'LBL_CREATED' => 'Utworzone przez',
  'LBL_CREATED_ID' => 'ID Tworzącego',
  'LBL_DESCRIPTION' => 'Treść',
  'LBL_HEADER' => 'Nagłówek',
  'LBL_FOOTER' => 'Stopka',
  'LBL_DELETED' => 'Usunięte',
  'LBL_NAME' => 'Nazwa',
  'LBL_CREATED_USER' => 'Utworzomy przez Użytkownika',
  'LBL_MODIFIED_USER' => 'Zmodyfikowany przez Użytkownika',
  'LBL_LIST_FORM_TITLE' => 'Lista szablonów PDF',
  'LBL_MODULE_NAME' => 'Szablony PDF',
  'LBL_MODULE_TITLE' => 'PDF Templates: Home',
  'LBL_HOMEPAGE_TITLE' => 'Moje szablony PDF',
  'LNK_NEW_RECORD' => 'Utwórz szablon PDF',
  'LNK_LIST' => 'Zobacz szablony PDF',
  'LBL_SEARCH_FORM_TITLE' => 'Search PDF Templates',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Działania',
  'LBL_AOS_PDF_TEMPLATES_SUBPANEL_TITLE' => 'Szablony PDF',
  'LBL_NEW_FORM_TITLE' => 'Nowy szablon PDF',
  'LBL_TYPE' => 'Typ',
  'LBL_ACTIVE' => 'Aktywny',
  'LBL_DEFAULT_TEMPLATE' => 'Domyślny szablon',
  'LBL_BUTTON_INSERT' => 'Wprowadź',
  'LBL_WARNING_OVERWRITE' => 'Warning this will overwrite you current Work',
  'LBL_INSERT_FIELDS' => 'Insert Fields',
  
  'LBL_SAMPLE' => 'Load Sample',
  'LBL_PAGE' => 'Strona',
  'LBL_PREPARED_FOR' => 'Prepared For',
  'LBL_PREPARED_BY' => 'Przygotowany przez',
  'LBL_QUOTE_SAMPLE' => 'Quote Sample',
  'LBL_INVOICE_SAMPLE' => 'Próbka faktury',
  'LBL_ACCOUNT_SAMPLE' => 'Przykładowe konto',
  'LBL_CONTACT_SAMPLE' => 'Contact Sample',
  'LBL_LEAD_SAMPLE' => 'Lead Sample',
  'LBL_ANY_STREET' => 'Any Street',
  'LBL_ANY_TOWN' => 'Any Town',
  'LBL_ANY_WHERE' => 'Any Where',
  
  'LBL_QUOTE_GROUP_SAMPLE' => 'Quote Group Sample',
  'LBL_INVOICE_GROUP_SAMPLE' => 'Invoice Group Sample',
  'LBL_MARGIN_LEFT' => 'Margin Left',
  'LBL_MARGIN_RIGHT' => 'Margin Right',
  'LBL_MARGIN_TOP' => 'Margin Top',
  'LBL_MARGIN_BOTTOM' => 'Margin Bottom',
  'LBL_MARGIN_HEADER' => 'Margin Header',
  'LBL_MARGIN_FOOTER' => 'Margin Footer',
  'LBL_EDITVIEW_PANEL1' => 'Margins',
  'LBL_DETAILVIEW_PANEL1' => 'Margins',
);
?>
